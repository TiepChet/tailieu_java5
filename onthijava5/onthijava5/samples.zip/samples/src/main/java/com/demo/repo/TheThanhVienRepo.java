package com.demo.repo;

import com.demo.entity.TheThanhVien;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TheThanhVienRepo extends JpaRepository<TheThanhVien, String> {

}
